
import pytest

@pytest.fixture(scope='function')
def page_context():
    # placeholder fixture for users to adapt; requires playwright to be installed
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        yield page
        browser.close()
